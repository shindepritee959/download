<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;

/**
 * Installer script for the miniOrange package.
 *
 * Note: The class name MUST match Joomla's expected name:
 * element (cleaned) + "InstallerScript" => pkg_importexportusersInstallerScript
 */
class pkg_downloadInstallerScript
{
    /**
     * Runs right after any installation action is performed.
     *
     * @param  string    $type   install|update|discover_install|uninstall
     * @param  \stdClass $parent Parent object calling object.
     *
     * @return void
     */
    public function postflight($type, $parent)
    {
        // Show only after updates (when admin clicks "Update")
        if ($type !== 'update') {
            return;
        }

        $app = Factory::getApplication();

        // Administrator-only message
        if (method_exists($app, 'isClient') && !$app->isClient('administrator')) {
            return;
        }

        $app->enqueueMessage(
            'Please follow the steps below to update your miniOrange Joomla extension:<br>'
            . '1. Visit https://portal.miniorange.com/downloads and log in using your miniOrange account credentials.<br>'
            . '2. Navigate to the Downloads section and download the latest version of your extension.<br>'
            . '3. Take a complete backup of your Joomla site, including the extension configuration.<br>'
            . '4. Go to Joomla Administrator → System → Install → Extensions and upload the downloaded ZIP file to update the extension.<br>'
            . 'If you need any assistance, please contact us at joomlasupport@xecurify.com.',
            'warning'
        );
    }
}

