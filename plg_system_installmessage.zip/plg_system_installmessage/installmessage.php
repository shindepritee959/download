<?php
/**
 * Plugin file intentionally contains no runtime logic.
 * The install message is shown via script.php (installer script).
 */
defined('_JEXEC') or die;

// Joomla will include this file when loading plugins.
// No events are implemented on purpose.

